
Galeria de Fotos
        
        Aqui estão as <?php echo $qt; ?> fotos.