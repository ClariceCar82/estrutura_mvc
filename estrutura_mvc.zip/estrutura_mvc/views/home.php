<h1>Olá <?php echo $nome; ?>, Feliz Aniversário, você tem <?php echo $idade; ?> anos</h1>
<h3>Voce tem <?php echo $quantidade; ?> anuncios</h3>
<img src="https://www.google.com.br/google.jpg">