<?php


class galeriaController extends controller{
      public function index() {
          $dados = array(
     'qt' => 120
    );
          $this->loadTemplate('galeria', $dados);
      }
}
